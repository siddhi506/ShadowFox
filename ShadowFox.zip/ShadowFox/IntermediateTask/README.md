# Delhi Air Quality Analysis 🌫️

## Objective
Analyze hourly air pollution data from Delhi to understand pollutant
behavior, temporal trends, and health implications.

## Dataset
Hourly air quality data provided by the organization (January 2023).

## Key Findings
- PM2.5 is the dominant pollutant
- Pollution peaks during night and early morning hours
- Strong correlation between PM2.5 and PM10

## Tools Used
Python, Pandas, Matplotlib, Seaborn, SciPy

## Author
Siddhi Sharma  
Data Science Intern
